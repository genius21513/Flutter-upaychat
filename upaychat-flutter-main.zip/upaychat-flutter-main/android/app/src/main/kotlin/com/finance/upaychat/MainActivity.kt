package com.finance.upaychat

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
